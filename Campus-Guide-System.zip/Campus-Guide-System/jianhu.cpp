// jianhu.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "mywork.h"
#include "jianhu.h"
#include "afxdialogex.h"


// jianhu �Ի���

IMPLEMENT_DYNAMIC(jianhu, CDialogEx)

jianhu::jianhu(CWnd* pParent /*=NULL*/)
	: CDialogEx(jianhu::IDD, pParent)
{

}

jianhu::~jianhu()
{
}

void jianhu::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(jianhu, CDialogEx)
END_MESSAGE_MAP()


// jianhu ��Ϣ��������
