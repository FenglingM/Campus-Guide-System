// tusguguan.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "mywork.h"
#include "tushuguan.h"
#include "afxdialogex.h"


// tusguguan �Ի���

IMPLEMENT_DYNAMIC(tushuguan, CDialogEx)

tushuguan::tushuguan(CWnd* pParent /*=NULL*/)
	: CDialogEx(tushuguan::IDD, pParent)
{

}

tushuguan::~tushuguan()
{
}

void tushuguan::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(tushuguan, CDialogEx)
END_MESSAGE_MAP()


// tusguguan ��Ϣ��������
