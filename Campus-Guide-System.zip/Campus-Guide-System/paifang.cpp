// paifang.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "mywork.h"
#include "paifang.h"
#include "afxdialogex.h"


// paifang �Ի���

IMPLEMENT_DYNAMIC(paifang, CDialogEx)

paifang::paifang(CWnd* pParent /*=NULL*/)
	: CDialogEx(paifang::IDD, pParent)
{

}

paifang::~paifang()
{
}

void paifang::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(paifang, CDialogEx)
END_MESSAGE_MAP()


// paifang ��Ϣ��������
