// zhujiao.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "mywork.h"
#include "zhujiao.h"
#include "afxdialogex.h"


// zhujiao �Ի���

IMPLEMENT_DYNAMIC(zhujiao, CDialogEx)

zhujiao::zhujiao(CWnd* pParent /*=NULL*/)
	: CDialogEx(zhujiao::IDD, pParent)
{

}

zhujiao::~zhujiao()
{
}

void zhujiao::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(zhujiao, CDialogEx)
END_MESSAGE_MAP()


// zhujiao ��Ϣ��������
