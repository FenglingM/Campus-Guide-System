// gongcao.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "mywork.h"
#include "gongcao.h"
#include "afxdialogex.h"


// gongcao �Ի���

IMPLEMENT_DYNAMIC(gongcao, CDialogEx)

gongcao::gongcao(CWnd* pParent /*=NULL*/)
	: CDialogEx(gongcao::IDD, pParent)
{

}

gongcao::~gongcao()
{
}

void gongcao::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(gongcao, CDialogEx)
END_MESSAGE_MAP()


// gongcao ��Ϣ��������
