// faxueyuan.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "mywork.h"
#include "faxueyuan.h"
#include "afxdialogex.h"


// faxueyuan �Ի���

IMPLEMENT_DYNAMIC(faxueyuan, CDialogEx)

faxueyuan::faxueyuan(CWnd* pParent /*=NULL*/)
	: CDialogEx(faxueyuan::IDD, pParent)
{

}

faxueyuan::~faxueyuan()
{
}

void faxueyuan::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(faxueyuan, CDialogEx)
END_MESSAGE_MAP()


// faxueyuan ��Ϣ��������
