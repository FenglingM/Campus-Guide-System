#include "stdafx.h"
#include "mywork.h"
#include "picture.h"

picture::picture()
{

}

picture::~picture()
{

}
