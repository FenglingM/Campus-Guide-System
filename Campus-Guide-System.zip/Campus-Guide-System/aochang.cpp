// aochang.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "mywork.h"
#include "aochang.h"
#include "afxdialogex.h"


// aochang �Ի���

IMPLEMENT_DYNAMIC(aochang, CDialogEx)

aochang::aochang(CWnd* pParent /*=NULL*/)
	: CDialogEx(aochang::IDD, pParent)
{

}

aochang::~aochang()
{
}

void aochang::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(aochang, CDialogEx)
END_MESSAGE_MAP()


// aochang ��Ϣ��������
