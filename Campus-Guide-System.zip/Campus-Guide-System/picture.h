#define N 12

class CPointA : public CPoint {    
public:
	double x;    //�������
	double y;    
};

class picture  
{
public:
	picture();
	virtual ~picture();

};